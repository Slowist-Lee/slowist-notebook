from pwn import *
from wstube import websocket
context.proxy = (socks.SOCKS5, "localhost", 1081)
context.log_level= 'DEBUG'
context.arch = 'amd64'
p= websocket("wss://ctf.zjusec.com/api/proxy/065bb806-2e62-43c6-a12a-f1b47d37e60a")
add_code=b"\xf3\x0f\x1e\xfa\x48\x83\xec\x08\x48\x8d\x3d\x00\x00\x00\x00\xe8\x00\x00\x00\x00\x31\xc0\x48\x83\xc4\x08\xc3"
p.sendafter(b"Request-1:give me code that performing ADD",add_code)
p.interactive()